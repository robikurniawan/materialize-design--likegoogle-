<!DOCTYPE html>
<html lang="en">
  
<!-- Mirrored from materializecss.com/getting-started.html by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 08 Apr 2017 01:47:20 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=utf-8" /><!-- /Added by HTTrack -->
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="msapplication-tap-highlight" content="no">
    <meta name="description" content="Learn how to quickly get started using our CSS framework. We have guides for a variety of skill levels.">
    <title>Getting Started - Materialize</title>
    <!-- Favicons-->
    <link rel="apple-touch-icon-precomposed" href="images/favicon/apple-touch-icon-152x152.png">
    <meta name="msapplication-TileColor" content="#FFFFFF">
    <meta name="msapplication-TileImage" content="images/favicon/mstile-144x144.png">
    <link rel="icon" href="images/favicon/favicon-32x32.png" sizes="32x32">
    <!--  Android 5 Chrome Color-->
    <meta name="theme-color" content="#EE6E73">
    <!-- CSS-->
    <link href="css/prism.css" rel="stylesheet">
    <link href="css/ghpages-materialize.css" type="text/css" rel="stylesheet" media="screen,projection">
    <link href="http://fonts.googleapis.com/css?family=Inconsolata" rel="stylesheet" type="text/css">
    <link href="http://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <script>
      window.liveSettings = {
        api_key: "a0b49b34b93844c38eaee15690d86413",
        picker: "bottom-right",
        detectlang: true,
        dynamic: true,
        autocollect: true
      };
    </script>
    <script src="../cdn.transifex.com/live.js"></script>
  </head>
  <body>
<?php include "side.php"; ?>

    </header>
    <main>
    <div class="section" id="index-banner">
      <div class="container">
        <div class="row">
          <div class="col s12 m9">
            <h1 class="header center-on-small-only">Selamat Datang</h1>
            <h4 class ="light red-text text-lighten-4 center-on-small-only">kopitani.id <br/> Dedikasi Untuk Petani Kopi Indonesia.</h4>
          </div>
        </div>
      </div>
    </div>

  <div class="container">
  <!--  Outer row  -->
  <div class="row">

          

    <!-- <div class="section col s12 m9 l10">
        <p class="caption col s12">Materialize comes in two different forms. You can select which version you want depending on your preference and expertise. To start using Materialize, all you have to do is download one of the options below.</p>
    </div> -->

    </main>


    <!--  Scripts-->
    <script src="../code.jquery.com/jquery-2.1.4.min.js"></script>
    <script>if (!window.jQuery) { document.write('<script src="bin/jquery-2.1.1.min.html"><\/script>'); }
    </script>
    <script src="js/jquery.timeago.min.js"></script>
    <script src="js/prism.js"></script>
    <script src="jade/lunr.min.js"></script>
    <script src="jade/search.js"></script>
    <script src="bin/materialize.js"></script>
    <script src="js/init.js"></script>
    <!-- Twitter Button -->
    <script>!function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0],p=/^http:/.test(d.location)?'http':'https';if(!d.getElementById(id)){js=d.createElement(s);js.id=id;js.src=p+'://platform.twitter.com/widgets.js';fjs.parentNode.insertBefore(js,fjs);}}(document, 'script', 'twitter-wjs');</script>

    <!-- Google Plus Button-->
    <script src="../apis.google.com/js/platform.js" async defer></script>

    <!--  Google Analytics  -->
    <script>
    (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
    (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
    m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
    })(window,document,'script','../www.google-analytics.com/analytics.js','ga');

    ga('create', 'UA-56218128-1', 'auto');
    ga('require', 'displayfeatures');
    ga('send', 'pageview');
    </script>

    <script>
      $('#download-source, #download-sass').on('click', function () {
        $('#download').slideUp(
          { duration: 500,
            easing: "easeOutQuart",
            queue: false,
            complete: function()
              { $('#download-thanks').slideDown({ duration: 300,
            easing: "easeOutQuart"}); }
          });
      
      });
    </script>
  </body>

<!-- Mirrored from materializecss.com/getting-started.html by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 08 Apr 2017 01:47:52 GMT -->
</html>